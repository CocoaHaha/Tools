//
//  WQXWebView.h
//  WQXTools
//
//  Created by 温群香 on 2020/12/9.
//

#import <UIKit/UIKit.h>

#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol WQXWebViewDelegate;

@interface WQXWebView : UIView

@property (nonatomic, weak) id<WQXWebViewDelegate> wqx_delegate;

/** 网页黑名单，黑名单里面的网址不会被加载，例如添加：www.example.com，那么就不会加载 */
@property (nonatomic, copy) NSArray<NSString *> *wqx_blackList;

/** 通过Universal Links跳转App，把允许跳转的添加在这里，例如 (末尾记得加/) ：https://www.example.com/ */
@property (nonatomic, copy) NSArray<NSString *> *wqx_universalLinks;

/** js交互，将需要js交互的方法名写在这里 */
@property (nonatomic, copy) NSArray<NSString *> *wqx_scriptMessageNames;

/** 自定义UserAgent */
@property (nonatomic, copy) NSString *wqx_customUserAgent;

/** 是否可以后退 */
@property (nonatomic, readonly) BOOL wqx_canGoBack;

/** 是否可以前进 */
@property (nonatomic, readonly) BOOL wqx_canGoForward;

/** 加载请求 */
- (void)wqx_loadRequest:(NSURLRequest *)request;

/** 加载请求 */
- (void)wqx_loadWithURLString:(NSString *)URLString;

/** 加载HTMLString，如果只加载本地HTML字符串，则baseURLString直接填nil，如果加载网页并自定义HTML，那这里填写网页的URL地址 */
- (void)wqx_loadHTMLString:(NSString *)string baseURLString:(NSString *)baseURLString;

/**
 加载Data，如果只加载本地data，则baseURLString直接填nil，如果加载网页并自定义data，那么这里填写网页的URL地址
 data：                  需要加载的数据
 MIMEType：              数据类型，例如："text/html"
 characterEncodingName： 编码类型，例如："UTF-8"
 baseURLString：         URL字符串
 */
- (void)wqx_loadData:(NSData *)data MIMEType:(NSString *)MIMEType characterEncodingName:(NSString *)characterEncodingName baseURLString:(NSString *)baseURLString;

/** 回退 */
- (void)wqx_goBack;

/** 前进 */
- (void)wqx_goForward;

/** 重新加载 */
- (void)wqx_reload;

/** 重新加载当前页面，并在可能的情况下使用缓存验证条件执行端到端重新验证。 */
- (void)wqx_reloadFromOrigin;

/** 停止加载当前页面上的所有资源。 */
- (void)wqx_stopLoading;

/** 清空缓存 */
- (void)wqx_removeWebCache;

/*
 注入js代码
 javaScriptString：  需要注入的js代码
 injectionTime：     将该代码注入到开头还是末尾
 forMainFrameOnly：  全局通用还是只用于MainFrame
 */
- (void)wqx_addUserScript:(NSString *)javaScriptString
            injectionTime:(WKUserScriptInjectionTime)injectionTime
         forMainFrameOnly:(BOOL)forMainFrameOnly;

/** 注入cookie，需要在加载网页之前调用 */
- (void)wqx_addCookie:(NSString *)cookie forURLString:(NSString *)URLString;

/**
 js交互，iOS调用js的方法
 javaScriptString：格式：js方法名('参数0', '参数1', '参数2')，eg：javaScriptFunction('张三', '15岁', '男')
 completionHandler：回调
 */
- (void)wqx_evaluateJavaScript:(NSString *)javaScriptString completionHandler:(void (^)(id result, NSError *error))completionHandler;

@end

@protocol WQXWebViewDelegate <NSObject>

@optional
/** js交互，收到传递过来的消息 */
- (void)wqx_webView:(WQXWebView *)webView didReceiveScriptMessage:(WKScriptMessage *)message;
/** 网页标题被改变时会调用该方法 */
- (void)wqx_webView:(WQXWebView *)webView didChangeTitle:(NSString *)title;
/** 网页URL被改变时会调用该方法*/
- (void)wqx_webView:(WQXWebView *)webView didChangeURL:(NSURL *)URL;
/** 网页加载状态被改变时会调用该方法 */
- (void)wqx_webView:(WQXWebView *)webView didChangeLoadingState:(BOOL)isLoading;
/** 网页加载进度被改变时会调用该方法 */
- (void)wqx_webView:(WQXWebView *)webView didChangeProgress:(CGFloat)progress;

#pragma mark - WKNavigationDelegate
/** 开始请求服务器并加载页面 */
- (void)wqx_webView:(WQXWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation;
/** 接收到服务器跳转请求即服务重定向时之后调用 */
- (void)wqx_webView:(WQXWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation;
/** 请求服务器发生错误 (如果是goBack时，当前页面也会回调这个方法，原因是NSURLErrorCancelled取消加载) */
- (void)wqx_webView:(WQXWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error;
/** 开始渲染页面时调用，响应的内容到达主页面的时候响应,刚准备开始渲染页面 */
- (void)wqx_webView:(WQXWebView *)webView didCommitNavigation:(WKNavigation *)navigation;
/** 页面渲染完成后调用 */
- (void)wqx_webView:(WQXWebView *)webView didFinishNavigation:(WKNavigation *)navigation;
/** 页面加载出错调用 */
- (void)wqx_webView:(WQXWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error;
/**
 当需要验证身份时调用,与使用AFN进行HTTPS证书验证是一样的
 如果不要求验证，传默认就行
 必须处理completionHandler
 当处理方案是NSURLSessionAuthChallengeUseCredential时，凭证参数是要使用的凭证，或者nil表示在没有凭证的情况下继续.
 */
- (void)wqx_webView:(WQXWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *credential))completionHandler;

#pragma mark - WKUIDelegate
/** 弹出一个只有确认按钮的提示框，如果不实现该方法，我会默认弹出一个 */
- (void)wqx_webView:(WQXWebView *)webView showAlertPanelWithMessage:(NSString *)message completionHandler:(void (^)(void))completionHandler;
/** 弹出一个有确认和取消按钮的提示框，如果不实现该方法，我会默认弹出一个 */
- (void)wqx_webView:(WQXWebView *)webView showConfirmPanelWithMessage:(NSString *)message completionHandler:(void (^)(BOOL result))completionHandler;
/** 弹出一个有确认和取消按钮的输入框，如果不实现该方法，我会默认弹出一个 */
- (void)wqx_webView:(WQXWebView *)webView showTextInputPanelWithPrompt:(NSString *)prompt defaultText:(nullable NSString *)defaultText completionHandler:(void (^)(NSString * result))completionHandler;

@end

NS_ASSUME_NONNULL_END
