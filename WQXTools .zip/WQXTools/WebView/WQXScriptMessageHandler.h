//
//  WQXScriptMessageHandler.h
//  WQXTools
//
//  Created by 温群香 on 2020/12/9.
//

#import <Foundation/Foundation.h>

#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface WQXScriptMessageHandler : NSObject<WKScriptMessageHandler>

@property (nonatomic, weak) id<WKScriptMessageHandler> wqx_delegate;

+ (instancetype)wqx_initWithDelegate:(id<WKScriptMessageHandler>)delegate;

@end

NS_ASSUME_NONNULL_END
