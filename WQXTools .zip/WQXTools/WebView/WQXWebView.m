//
//  WQXWebView.m
//  WQXTools
//
//  Created by 温群香 on 2020/12/9.
//

#import "WQXWebView.h"

#import "WQXScriptMessageHandler.h"

@interface WQXWebView ()<WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate>

@property (nonatomic, strong) WKWebView *wqx_webView;
/** 专门用来加载cookie的webview */
@property (nonatomic, strong) WKWebView *wqx_cookieWebView;
/** 记录是否需要先加载cookie，如果手动添加了cookie，则需要先加载cookie */
@property (nonatomic, assign) BOOL wqx_needLoadCookie;
/** 如果需要先加载cookie，则先把request保存，然后在cookie加载完毕后加载该request */
@property (nonatomic, strong) NSURLRequest *wqx_request;
/** 如果需要先加载cookie，则先把URLString保存，然后在cookie加载完毕后加载该URLString */
@property (nonatomic, copy) NSString *wqx_URLString;
/** 如果需要先加载cookie，则先把HTMLString保存，然后在cookie加载完毕后加载该HTMLString */
@property (nonatomic, copy) NSString *wqx_HTMLString;
@property (nonatomic, copy) NSString *wqx_baseURLString;
/** 如果需要先加载cookie，则先把data保存，然后在cookie加载完毕后加载该data */
@property (nonatomic, strong) NSData *wqx_data;
@property (nonatomic, copy) NSString *wqx_MIMEType;
@property (nonatomic, copy) NSString *wqx_characterEncodingName;

@end

@implementation WQXWebView

- (void)dealloc {
    [self deinit];
    if (DEBUG) {
        NSLog(@"- [%@ dealloc]", NSStringFromClass([self class]));
    }
}

/** 销毁数据 */
- (void)deinit {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_wqx_webView removeObserver:self forKeyPath:@"URL"];
    [_wqx_webView removeObserver:self forKeyPath:@"estimatedProgress"];
    [_wqx_webView.configuration.userContentController removeAllUserScripts];
    if (_wqx_scriptMessageNames.count) {
        for (NSString *name in _wqx_scriptMessageNames) {
            [_wqx_webView.configuration.userContentController removeScriptMessageHandlerForName:name];
        }
    }
    _wqx_webView.navigationDelegate = nil;
    _wqx_webView.UIDelegate = nil;
    _wqx_webView = nil;
    if (_wqx_cookieWebView) {
        [_wqx_cookieWebView.configuration.userContentController removeAllUserScripts];
        _wqx_cookieWebView.navigationDelegate = nil;
        _wqx_cookieWebView = nil;
    }
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self config];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        [self config];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self config];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.wqx_webView.frame = self.bounds;
}

- (void)config {
    [self addSubview:self.wqx_webView];
}

#pragma mark - private func
- (void)changeTitle:(NSString *)title {
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didChangeTitle:)]) {
        [self.wqx_delegate wqx_webView:self didChangeTitle:title];
    }
}

- (void)changeLoadingState:(BOOL)isLoading {
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didChangeLoadingState:)]) {
        [self.wqx_delegate wqx_webView:self didChangeLoadingState:isLoading];
    }
}

#pragma mark - public func
/** 加载请求 */
- (void)wqx_loadRequest:(NSURLRequest *)request {
    if (self.wqx_needLoadCookie) {
        self.wqx_request = request;
        [self.wqx_cookieWebView loadRequest:request];
    }else{
        [self.wqx_webView loadRequest:request];
    }
}

/** 加载请求 */
- (void)wqx_loadWithURLString:(NSString *)URLString {
    if (self.wqx_needLoadCookie) {
        self.wqx_URLString = URLString;
        [self.wqx_cookieWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:URLString]]];
    }else{
        [self.wqx_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:URLString]]];
    }
}

/** 加载HTMLString，如果只加载本地HTML字符串，则baseURLString直接填nil，如果加载网页并自定义HTML，那这里填写网页的URL地址 */
- (void)wqx_loadHTMLString:(NSString *)string baseURLString:(NSString *)baseURLString {
    if (self.wqx_needLoadCookie) {
        self.wqx_HTMLString = string;
        self.wqx_baseURLString = baseURLString;
        [self.wqx_cookieWebView loadHTMLString:string baseURL:[NSURL URLWithString:baseURLString]];
    }else{
        [self.wqx_webView loadHTMLString:string baseURL:[NSURL URLWithString:baseURLString]];
    }
}

/**
 加载Data，如果只加载本地data，则baseURLString直接填nil，如果加载网页并自定义data，那么这里填写网页的URL地址
 data：                  需要加载的数据
 MIMEType：              数据类型，例如："text/html"
 characterEncodingName： 编码类型，例如："UTF-8"
 baseURLString：         URL字符串
 */
- (void)wqx_loadData:(NSData *)data MIMEType:(NSString *)MIMEType characterEncodingName:(NSString *)characterEncodingName baseURLString:(NSString *)baseURLString {
    if (self.wqx_needLoadCookie) {
        self.wqx_data = data;
        self.wqx_MIMEType = MIMEType;
        self.wqx_characterEncodingName = characterEncodingName;
        self.wqx_baseURLString = baseURLString;
        [self.wqx_cookieWebView loadData:data MIMEType:MIMEType characterEncodingName:characterEncodingName baseURL:[NSURL URLWithString:baseURLString]];
    }else{
        [self.wqx_webView loadData:data MIMEType:MIMEType characterEncodingName:characterEncodingName baseURL:[NSURL URLWithString:baseURLString]];
    }
}

/** 回退 */
- (void)wqx_goBack {
    [self.wqx_webView goBack];
}

/** 前进 */
- (void)wqx_goForward {
    [self.wqx_webView goForward];
}

/** 重新加载 */
- (void)wqx_reload {
    [self.wqx_webView reload];
}

/** 重新加载当前页面，并在可能的情况下使用缓存验证条件执行端到端重新验证。 */
- (void)wqx_reloadFromOrigin {
    [self.wqx_webView reloadFromOrigin];
}

/** 停止加载当前页面上的所有资源。 */
- (void)wqx_stopLoading {
    [self.wqx_webView stopLoading];
    [self changeLoadingState:NO];
}

/** 清空缓存 */
- (void)wqx_removeWebCache {
    if (@available(iOS 9.0, *)) {
        NSSet *types = [WKWebsiteDataStore allWebsiteDataTypes];
        NSDate *date = [NSDate dateWithTimeIntervalSince1970:0];
        [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:types modifiedSince:date completionHandler:^{

        }];
    }else {
        NSString *libraryPath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) firstObject];
        NSString *cookiesPath = [libraryPath stringByAppendingPathComponent:@"Cookies"];
        [[NSFileManager defaultManager] removeItemAtPath:cookiesPath error:nil];
    }
}

/*
 注入js代码
 javaScriptString：  需要注入的js代码
 injectionTime：     将该代码注入到开头还是末尾
 forMainFrameOnly：  全局通用还是只用于MainFrame
 */
- (void)wqx_addUserScript:(NSString *)javaScriptString
            injectionTime:(WKUserScriptInjectionTime)injectionTime
         forMainFrameOnly:(BOOL)forMainFrameOnly {
    WKUserScript *script = [[WKUserScript alloc] initWithSource:javaScriptString injectionTime:injectionTime forMainFrameOnly:forMainFrameOnly];
    [self.wqx_webView.configuration.userContentController addUserScript:script];
}

/** 注入cookie，需要在加载网页之前调用 */
- (void)wqx_addCookie:(NSString *)cookie forURLString:(NSString *)URLString {
    if (![cookie isKindOfClass:[NSString class]] || cookie.length == 0) return;
    if (![URLString isKindOfClass:[NSString class]]) return;

    // 先看看之前有没有该cookie或者看下cookie是否更新了，如果有就没必要再加载了
    NSString *cookieCache = [[WQXWebView sharedCookieCache] objectForKey:URLString];
    if (cookieCache == nil || ![cookieCache isEqualToString:cookie]) {
        self.wqx_needLoadCookie = YES;
        WKUserScript *script = [[WKUserScript alloc] initWithSource:cookie injectionTime:WKUserScriptInjectionTimeAtDocumentStart forMainFrameOnly:NO];
        [self.wqx_cookieWebView.configuration.userContentController addUserScript:script];
        if (![self.subviews containsObject:self.wqx_cookieWebView]) {
            [self addSubview:self.wqx_cookieWebView];
        }
    }
}

/**
 js交互，iOS调用js的方法
 javaScriptString：格式：js方法名('参数0', '参数1', '参数2')，eg：javaScriptFunction('张三', '15岁', '男')
 completionHandler：回调
 */
- (void)wqx_evaluateJavaScript:(NSString *)javaScriptString completionHandler:(void (^)(id result, NSError *error))completionHandler {
    [self.wqx_webView evaluateJavaScript:javaScriptString completionHandler:completionHandler];
}

#pragma mark - Observer
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if ([object isEqual:_wqx_webView]) {
        if ([keyPath isEqualToString:@"URL"]) {
            if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didChangeURL:)]) {
                [self.wqx_delegate wqx_webView:self didChangeURL:change[NSKeyValueChangeNewKey]];
            }
        }else if ([keyPath isEqualToString:@"estimatedProgress"]) {
            CGFloat value = [change[NSKeyValueChangeNewKey] floatValue];
            if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didChangeProgress:)]) {
                [self.wqx_delegate wqx_webView:self didChangeProgress:value];
            }
        }
    }
}

#pragma mark - setter
/** 添加js交互 */
- (void)setWqx_scriptMessageNames:(NSArray<NSString *> *)wqx_scriptMessageNames {
    // 先移除之前的
    if (_wqx_scriptMessageNames.count) {
        for (NSString *name in _wqx_scriptMessageNames) {
            [_wqx_webView.configuration.userContentController removeScriptMessageHandlerForName:name];
        }
    }
    _wqx_scriptMessageNames = wqx_scriptMessageNames;
    // 再添加新的
    if (_wqx_scriptMessageNames.count) {
        for (NSString *name in _wqx_scriptMessageNames) {
            [_wqx_webView.configuration.userContentController addScriptMessageHandler:[WQXScriptMessageHandler wqx_initWithDelegate:self] name:name];
        }
    }
}

/** 自定义UserAgent */
- (void)setWqx_customUserAgent:(NSString *)wqx_customUserAgent {
    _wqx_customUserAgent = wqx_customUserAgent;
    _wqx_webView.customUserAgent = wqx_customUserAgent;
}

#pragma mark - 解决第一次注入cookie时无法拿到cookie的问题
+ (WKProcessPool *)sharedProcessPool {
    static WKProcessPool *pool = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        pool = [WKProcessPool new];
    });
    return pool;
}

/**
 解决第一次注入cookie无效的问题
 方案：每次都将注入的cookie缓存，如果缓存里没有则说明是第一次加载该cookie，那么用一个cookieWebView加载cookie，加载完成后再用webview加载内容即可
 */
+ (NSMutableDictionary *)sharedCookieCache {
    static NSMutableDictionary *dictionary = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dictionary = [NSMutableDictionary new];
    });
    return dictionary;
}

#pragma mark - 懒加载
- (WKWebView *)wqx_webView {
    if (!_wqx_webView) {
        // WKWebView配置信息
        WKWebViewConfiguration *configuration = [WKWebViewConfiguration new];
        // WKWebView内容处理池
        configuration.processPool = [WQXWebView sharedProcessPool];
        // WKWebView偏好设置
        WKPreferences *preferences = [WKPreferences new];
        preferences.javaScriptEnabled = YES;
        preferences.javaScriptCanOpenWindowsAutomatically = YES;
        configuration.preferences = preferences;

        // 用户交互
        WKUserContentController *userContentController = [WKUserContentController new];
        configuration.userContentController = userContentController;
        // WKWebView识别电话、链接等
        configuration.dataDetectorTypes = WKDataDetectorTypeAll;
        // 允许音视频自动播放
        configuration.mediaTypesRequiringUserActionForPlayback = WKAudiovisualMediaTypeAll;
        configuration.allowsInlineMediaPlayback = YES;
        // 允许记忆读取
        configuration.suppressesIncrementalRendering = YES;
        if (@available (iOS 10.0, *)) {
            [configuration setValue:@YES forKey:@"allowUniversalAccessFromFileURLs"];
        }else{
            [configuration.preferences setValue:@YES forKey:@"allowFileAccessFromFileURLs"];
        }
        _wqx_webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:configuration];
        _wqx_webView.navigationDelegate = self;
        _wqx_webView.UIDelegate = self;
        _wqx_webView.allowsBackForwardNavigationGestures = YES;
        // 屏幕旋转自动调整宽高
        _wqx_webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        // 监听网页URL
        [_wqx_webView addObserver:self forKeyPath:@"URL" options:NSKeyValueObservingOptionNew context:nil];
        // 监听加载进度
        [_wqx_webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
    }
    return _wqx_webView;
}

- (WKWebView *)wqx_cookieWebView {
    if (!_wqx_cookieWebView) {
        // WKWebView配置信息
        WKWebViewConfiguration *configuration = [WKWebViewConfiguration new];
        // WKWebView内容处理池，共享cookie
        configuration.processPool = [WQXWebView sharedProcessPool];
        // 用户交互
        WKUserContentController *userContentController = [WKUserContentController new];
        configuration.userContentController = userContentController;

        _wqx_cookieWebView = [[WKWebView alloc] initWithFrame:CGRectMake(0, -1, 1, 1) configuration:configuration];
        _wqx_cookieWebView.navigationDelegate = self;
    }
    return _wqx_cookieWebView;
}

- (NSArray<NSString *> *)wqx_blackList {
    if (!_wqx_blackList) {
        _wqx_blackList = [[NSArray alloc] init];
    }
    return _wqx_blackList;
}

- (NSArray<NSString *> *)wqx_universalLinks {
    if (!_wqx_universalLinks) {
        _wqx_universalLinks = [[NSArray alloc] init];
    }
    return _wqx_universalLinks;
}

- (BOOL)wqx_canGoBack {
    return _wqx_webView.canGoBack;
}

- (BOOL)wqx_canGoForward {
    return _wqx_webView.canGoForward;
}

#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didReceiveScriptMessage:)]) {
        [self.wqx_delegate wqx_webView:self didReceiveScriptMessage:message];
    }
}

#pragma mark - WKNavigationDelegate
/** 是否允许页面加载 */
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    // 如果是通过Scheme启动app，需要手动跳转
    if (![navigationAction.request.URL.scheme hasPrefix:@"http"]) {
        if ([UIApplication.sharedApplication canOpenURL:navigationAction.request.URL]) {
            [UIApplication.sharedApplication openURL:navigationAction.request.URL options:@{} completionHandler:nil];
            decisionHandler(WKNavigationActionPolicyCancel);
            return;
        }
    }

    // 如果是通过Universal Links启动app，需要手动跳转
    if (self.wqx_universalLinks.count) {
        for (NSString *link in self.wqx_universalLinks) {
            if ([link isKindOfClass:[NSString class]]) {
                if ([navigationAction.request.URL.absoluteString isEqualToString:link.lowercaseString]) {
                    if ([UIApplication.sharedApplication canOpenURL:navigationAction.request.URL]) {
                        [UIApplication.sharedApplication openURL:navigationAction.request.URL options:@{} completionHandler:nil];
                        decisionHandler(WKNavigationActionPolicyCancel);
                        return;
                    }
                }
            }
        }
    }

    // 遍历黑名单
    BOOL allow = YES;
    if (self.wqx_blackList.count) {
        for (NSString *obj in self.wqx_blackList) {
            if ([obj isKindOfClass:[NSString class]] && obj.length) {
                if ([navigationAction.request.URL.host isEqualToString:obj.lowercaseString]) {
                    allow = NO;
                    break;
                }
            }
        }
    }
    if (allow) {
        decisionHandler(WKNavigationActionPolicyAllow);
    }else{
        decisionHandler(WKNavigationActionPolicyCancel);
    }
}

/** 收到服务器响应后，决定是否跳转 */
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    decisionHandler(WKNavigationResponsePolicyAllow);
}

/** 开始请求服务器并加载页面 */
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [self changeTitle:NSLocalizedString(@"加载中", nil)];
    [self changeLoadingState:YES];
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didStartProvisionalNavigation:)]) {
        [self.wqx_delegate wqx_webView:self didStartProvisionalNavigation:navigation];
    }
}

/** 接收到服务器跳转请求即服务重定向时之后调用 */
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [self changeTitle:NSLocalizedString(@"加载中", nil)];
    [self changeLoadingState:YES];
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didReceiveServerRedirectForProvisionalNavigation:)]) {
        [self.wqx_delegate wqx_webView:self didReceiveServerRedirectForProvisionalNavigation:navigation];
    }
}

/** 请求服务器发生错误 (如果是goBack时，当前页面也会回调这个方法，原因是NSURLErrorCancelled取消加载) */
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    [self changeTitle:NSLocalizedString(@"无法打开网页", nil)];
    [self changeLoadingState:NO];
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didFailProvisionalNavigation:withError:)]) {
        [self.wqx_delegate wqx_webView:self didFailProvisionalNavigation:navigation withError:error];
    }
}

/** 开始渲染页面时调用，响应的内容到达主页面的时候响应,刚准备开始渲染页面 */
- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation {
    if (webView == _wqx_cookieWebView) {
        return;
    }
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didCommitNavigation:)]) {
        [self.wqx_delegate wqx_webView:self didCommitNavigation:navigation];
    }
}

/** 页面渲染完成后调用 */
- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    if (webView == self.wqx_cookieWebView) {
        // 将该cookie缓存
        WKUserScript *cookie = self.wqx_cookieWebView.configuration.userContentController.userScripts.lastObject;
        if (cookie.source) {
            [[WQXWebView sharedCookieCache] setObject:cookie.source forKey:self.wqx_cookieWebView.URL.absoluteString];
        }

        [self.wqx_cookieWebView.configuration.userContentController removeAllUserScripts];
        self.wqx_cookieWebView.navigationDelegate = nil;
        [self.wqx_cookieWebView removeFromSuperview];
        self.wqx_cookieWebView = nil;
        self.wqx_needLoadCookie = NO;

        // cookie加载完毕后，再加载网页内容
        if (self.wqx_request) {
            [self.wqx_webView loadRequest:self.wqx_request];
            self.wqx_request = nil;
        }else if (self.wqx_URLString) {
            [self.wqx_webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.wqx_URLString]]];
            self.wqx_URLString = nil;
        }else if (self.wqx_HTMLString) {
            [self.wqx_webView loadHTMLString:self.wqx_HTMLString baseURL:[NSURL URLWithString:self.wqx_baseURLString]];
            self.wqx_HTMLString = nil;
            self.wqx_baseURLString = nil;
        }else if (self.wqx_data) {
            [self.wqx_webView loadData:self.wqx_data MIMEType:self.wqx_MIMEType characterEncodingName:self.wqx_characterEncodingName baseURL:[NSURL URLWithString:self.wqx_baseURLString]];
            self.wqx_data = nil;
            self.wqx_MIMEType = nil;
            self.wqx_characterEncodingName = nil;
            self.wqx_baseURLString = nil;
        }
        return;
    }
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    [self changeTitle:webView.title];
    [self changeLoadingState:NO];
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didFinishNavigation:)]) {
        [self.wqx_delegate wqx_webView:self didFinishNavigation:navigation];
    }
}

/** 页面加载出错调用 */
- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    [self changeTitle:NSLocalizedString(@"无法打开网页", nil)];
    [self changeLoadingState:NO];
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didFailNavigation:withError:)]) {
        [self.wqx_delegate wqx_webView:self didFailNavigation:navigation withError:error];
    }
}

/**
 当需要验证身份时调用,与使用AFN进行HTTPS证书验证是一样的
 如果不要求验证，传默认就行
 当处理方案是NSURLSessionAuthChallengeUseCredential时，凭证参数是要使用的凭证，或者nil表示在没有凭证的情况下继续.
 */
- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential * _Nullable credential))completionHandler {
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:didReceiveAuthenticationChallenge:completionHandler:)]) {
        [self.wqx_delegate wqx_webView:self didReceiveAuthenticationChallenge:challenge completionHandler:completionHandler];
        return;
    }
    completionHandler(NSURLSessionAuthChallengePerformDefaultHandling, nil);
}

/** 进程终止时调用，web内容处理中断时会调用 */
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {
    // 防止当WebView加载数据太多的时候会白屏
    [webView reload];
}

#pragma mark - WKUIDelegate
/** 当标签带有 target='_blank' 时，导致WKWebView无法加载点击后的网页的问题。 */
- (nullable WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures {
    if (!navigationAction.targetFrame.isMainFrame) {
        [webView loadRequest:navigationAction.request];
    }
    return nil;
}

/** 弹出一个只有确认按钮的提示框 */
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:showAlertPanelWithMessage:completionHandler:)]) {
        [self.wqx_delegate wqx_webView:self showAlertPanelWithMessage:message completionHandler:completionHandler];
    }else {
        // 如果你不实现该方法，那么我默认给你弹一个
        [self wqx_showAlertWithTitle:NSLocalizedString(@"温馨提示", nil) message:message cancelTitle:nil cancelHandler:nil confirmTitle:NSLocalizedString(@"确定", nil) confirmHandler:^{
            completionHandler();
        }];
    }
}

/** 弹出一个有确认和取消按钮的提示框 */
- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL result))completionHandler {
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:showConfirmPanelWithMessage:completionHandler:)]) {
        [self.wqx_delegate wqx_webView:self showConfirmPanelWithMessage:message completionHandler:completionHandler];
    }else {
        // 如果你不实现该方法，那么我默认给你弹一个
        [self wqx_showAlertWithTitle:NSLocalizedString(@"温馨提示", nil) message:message cancelTitle:NSLocalizedString(@"取消", nil) cancelHandler:^{
            completionHandler(NO);
        } confirmTitle:NSLocalizedString(@"确定", nil) confirmHandler:^{
            completionHandler(YES);
        }];
    }
}

/** 弹出一个有确认和取消按钮的输入框 */
- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(nullable NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable result))completionHandler {
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(wqx_webView:showTextInputPanelWithPrompt:defaultText:completionHandler:)]) {
        [self.wqx_delegate wqx_webView:self showTextInputPanelWithPrompt:prompt defaultText:defaultText completionHandler:completionHandler];
    }else {
        [self wqx_showTextInputAlertWithTitle:NSLocalizedString(@"温馨提示", nil) message:prompt textFieldConfigurationHandler:^(UITextField *textField) {
            textField.text = defaultText;
        } cancelTitle:NSLocalizedString(@"取消", nil) cancelHandler:^{
            // 在Safari中，点击取消按钮传递的是null
            completionHandler(defaultText);
        } confirmTitle:NSLocalizedString(@"确定", nil) confirmHandler:^(NSString *text) {
            completionHandler(text);
        }];
    }
}

#pragma mark - Alert
- (void)wqx_showAlertWithTitle:(NSString *)title
                       message:(NSString *)message
                   cancelTitle:(NSString *)cancelTitle
                 cancelHandler:(void (^)(void))cancelHandler
                  confirmTitle:(NSString *)confirmTitle
                confirmHandler:(void (^)(void))confirmHandler{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    if (cancelTitle && [cancelTitle isKindOfClass:[NSString class]] && cancelTitle.length > 0) {
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            cancelHandler ? cancelHandler() : nil;
        }];
        [alert addAction:cancel];
    }
    if (confirmTitle && [confirmTitle isKindOfClass:[NSString class]] && confirmTitle.length > 0) {
        UIAlertAction *confirm = [UIAlertAction actionWithTitle:confirmTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            confirmHandler ? confirmHandler() : nil;
        }];
        [alert addAction:confirm];
    }
    [UIApplication.sharedApplication.delegate.window.rootViewController presentViewController:alert animated:YES completion:nil];
}

- (void)wqx_showTextInputAlertWithTitle:(NSString *)title
                                message:(NSString *)message
          textFieldConfigurationHandler:(void (^)(UITextField *textField))textFieldConfigurationHandler
                            cancelTitle:(NSString *)cancelTitle
                          cancelHandler:(void (^)(void))cancelHandler
                           confirmTitle:(NSString *)confirmTitle
                         confirmHandler:(void (^)(NSString *text))confirmHandler{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:textFieldConfigurationHandler];
    if (cancelTitle && [cancelTitle isKindOfClass:[NSString class]] && cancelTitle.length > 0) {
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            cancelHandler ? cancelHandler() : nil;
        }];
        [alert addAction:cancel];
    }
    if (confirmTitle && [confirmTitle isKindOfClass:[NSString class]] && confirmTitle.length > 0) {
        UIAlertAction *confirm = [UIAlertAction actionWithTitle:confirmTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            confirmHandler ? confirmHandler(alert.textFields.firstObject.text) : nil;
        }];
        [alert addAction:confirm];
    }
    [UIApplication.sharedApplication.delegate.window.rootViewController presentViewController:alert animated:YES completion:nil];
}

@end
