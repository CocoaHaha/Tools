//
//  WQXScriptMessageHandler.m
//  WQXTools
//
//  Created by 温群香 on 2020/12/9.
//

#import "WQXScriptMessageHandler.h"

@implementation WQXScriptMessageHandler

+ (instancetype)wqx_initWithDelegate:(id<WKScriptMessageHandler>)delegate {
    WQXScriptMessageHandler *instance = [[WQXScriptMessageHandler alloc] init];
    instance.wqx_delegate = delegate;
    return instance;
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    if (self.wqx_delegate && [self.wqx_delegate respondsToSelector:@selector(userContentController:didReceiveScriptMessage:)]) {
        [self.wqx_delegate userContentController:userContentController didReceiveScriptMessage:message];
    }
}

@end
