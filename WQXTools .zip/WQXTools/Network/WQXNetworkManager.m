//
//  WQXNetworkManager.m
//  WQXTools
//
//  Created by 温群香 on 2020/12/7.
//

#import "WQXNetworkManager.h"

#if __has_include(<AFNetworking/AFNetworking.h>)
#import <AFNetworkActivityIndicatorManager.h>
#else
#import "AFNetworkActivityIndicatorManager.h"
#endif

@interface WQXNetworkManager ()

@property (nonatomic, strong) NSMutableArray *wqx_sessionTaskArray;
@property (nonatomic, strong) AFHTTPSessionManager *wqx_sessionManager;
@property (nonatomic, copy) void (^wqx_globalConfigBlock)(AFHTTPSessionManager *sessionManager);

@end

@implementation WQXNetworkManager

- (void)dealloc {
    if (DEBUG) {
        NSLog(@"- [%@ dealloc]", NSStringFromClass([self class]));
    }
}

+ (instancetype)wqx_sharedManager {
    static WQXNetworkManager *wqx_instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        wqx_instance = [[WQXNetworkManager alloc] init];
    });
    return wqx_instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _wqx_sessionTaskArray = [[NSMutableArray alloc] init];
        _wqx_sessionManager = [AFHTTPSessionManager manager];
        _wqx_sessionManager.securityPolicy = [AFSecurityPolicy defaultPolicy];
        _wqx_sessionManager.securityPolicy.allowInvalidCertificates = YES;
        _wqx_sessionManager.securityPolicy.validatesDomainName = NO;
        _wqx_sessionManager.requestSerializer.timeoutInterval = 30.0f;
        _wqx_sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/plain", @"text/html", nil];
        _wqx_queue = dispatch_queue_create("com.wenqunxiang.wqxtools.queue", DISPATCH_QUEUE_CONCURRENT);
        [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    }
    return self;
}

- (void)wqx_globalConfigWithBlock:(void(^)(AFHTTPSessionManager *sessionManager))completion {
    self.wqx_globalConfigBlock = completion;
}

/** 开始监听网络状态，一旦状态发生变化，将会通过block返回 */
- (void)wqx_startMonitoringNetworkStatus:(WQXNetworkStatusBlock)block {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
        [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
            switch (status) {
                case AFNetworkReachabilityStatusUnknown:
                    self->_wqx_networkStatus = WQXNetworkStatusUnknown;
                    block ? block(WQXNetworkStatusUnknown) : nil;
                    if (DEBUG) {
                        NSLog(@"当前网络状态：未知网络");
                    }
                    break;
                case AFNetworkReachabilityStatusNotReachable:
                    self->_wqx_networkStatus = WQXNetworkStatusNotReachable;
                    block ? block(WQXNetworkStatusNotReachable) : nil;
                    if (DEBUG) {
                        NSLog(@"当前网络状态：无网络");
                    }
                    break;
                case AFNetworkReachabilityStatusReachableViaWWAN:
                    self->_wqx_networkStatus = WQXNetworkStatusReachableViaWWAN;
                    block ? block(WQXNetworkStatusReachableViaWWAN) : nil;
                    if (DEBUG) {
                        NSLog(@"当前网络状态：运营商网络");
                    }
                    break;
                case AFNetworkReachabilityStatusReachableViaWiFi:
                    self->_wqx_networkStatus = WQXNetworkStatusReachableViaWiFi;
                    block ? block(WQXNetworkStatusReachableViaWiFi) : nil;
                    if (DEBUG) {
                        NSLog(@"当前网络状态：Wi-Fi网络");
                    }
                    break;

                default:
                    break;
            }
        }];
        [manager startMonitoring];
    });
}

/**
 GET请求

 @param path        请求路径或者请求完整URL字符串（如果是路径，则需要设置baseURL）
 @param parameters  请求参数
 @param success     请求成功的回调
 @param failure     请求失败的回调
 @return 返回的对象可取消请求，调用wqx_cancelRequestWithTask:方法
 */
- (NSURLSessionTask *)wqx_GET:(NSString *)path
                   parameters:(id)parameters
                      success:(WQXRequestSuccessBlock)success
                      failure:(WQXRequestFailedBlock)failure {
    if (self.wqx_globalConfigBlock) {
        self.wqx_globalConfigBlock(self.wqx_sessionManager);
    }
    __weak typeof(self) weakSelf = self;
    NSURLSessionTask *sessionTask = [self.wqx_sessionManager GET:path parameters:parameters headers:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [weakSelf.wqx_sessionTaskArray removeObject:task];
        success ? success(responseObject) : nil;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [weakSelf.wqx_sessionTaskArray removeObject:task];
        failure ? failure(error) : nil;
    }];
    sessionTask ? [self.wqx_sessionTaskArray addObject:sessionTask] : nil;
    return sessionTask;
}

/**
 POST请求

 @param path        请求路径或者请求完整URL字符串（如果是路径，则需要设置baseURL）
 @param parameters  请求参数
 @param success     请求成功的回调
 @param failure     请求失败的回调
 @return 返回的对象可取消请求，调用wqx_cancelRequestWithTask:方法
 */
- (NSURLSessionTask *)wqx_POST:(NSString *)path
                    parameters:(id)parameters
                       success:(WQXRequestSuccessBlock)success
                       failure:(WQXRequestFailedBlock)failure {
    if (self.wqx_globalConfigBlock) {
        self.wqx_globalConfigBlock(self.wqx_sessionManager);
    }
    __weak typeof(self) weakSelf = self;
    NSURLSessionTask *sessionTask = [self.wqx_sessionManager POST:path parameters:parameters headers:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [weakSelf.wqx_sessionTaskArray removeObject:task];
        success ? success(responseObject) : nil;
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [weakSelf.wqx_sessionTaskArray removeObject:task];
        failure ? failure(error) : nil;
    }];
    sessionTask ? [self.wqx_sessionTaskArray addObject:sessionTask] : nil;
    return sessionTask;
}

/**
 异步GET请求

 @param path        请求路径或者请求完整URL字符串（如果是路径，则需要设置baseURL）
 @param parameters  请求参数
 @param success     请求成功的回调
 @param failure     请求失败的回调
 */
- (void)wqx_asyncGET:(NSString *)path
          parameters:(id)parameters
             success:(WQXRequestSuccessBlock)success
             failure:(WQXRequestFailedBlock)failure {
    __weak typeof(self) weakSelf = self;
    dispatch_async(self.wqx_queue, ^{
        if (weakSelf.wqx_globalConfigBlock) {
            weakSelf.wqx_globalConfigBlock(weakSelf.wqx_sessionManager);
        }
        NSURLSessionTask *sessionTask = [weakSelf.wqx_sessionManager GET:path parameters:parameters headers:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            [weakSelf.wqx_sessionTaskArray removeObject:task];
            success ? success(responseObject) : nil;
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [weakSelf.wqx_sessionTaskArray removeObject:task];
            failure ? failure(error) : nil;
        }];
        sessionTask ? [weakSelf.wqx_sessionTaskArray addObject:sessionTask] : nil;
    });
}

/**
 异步POST请求

 @param path        请求路径或者请求完整URL字符串（如果是路径，则需要设置baseURL）
 @param parameters  请求参数
 @param success     请求成功的回调
 @param failure     请求失败的回调
 */
- (void)wqx_asyncPOST:(NSString *)path
           parameters:(id)parameters
              success:(WQXRequestSuccessBlock)success
              failure:(WQXRequestFailedBlock)failure {
    __weak typeof(self) weakSelf = self;
    dispatch_async(self.wqx_queue, ^{
        if (weakSelf.wqx_globalConfigBlock) {
            weakSelf.wqx_globalConfigBlock(weakSelf.wqx_sessionManager);
        }
        NSURLSessionTask *sessionTask = [weakSelf.wqx_sessionManager POST:path parameters:parameters headers:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            [weakSelf.wqx_sessionTaskArray removeObject:task];
            success ? success(responseObject) : nil;
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [weakSelf.wqx_sessionTaskArray removeObject:task];
            failure ? failure(error) : nil;
        }];
        sessionTask ? [weakSelf.wqx_sessionTaskArray addObject:sessionTask] : nil;
    });
}

/** 取消指定的HTTP请求 */
- (void)wqx_cancelRequestWithTask:(NSURLSessionTask *)task {
    if (!task) return;
    if (![task isKindOfClass:[NSURLSessionTask class]]) return;
    @synchronized (self) {
        for (id obj in self.wqx_sessionTaskArray) {
            if ([obj isEqual:task]) {
                [task cancel];
                [self.wqx_sessionTaskArray removeObject:obj];
                break;
            }
        }
    }
}

/** 取消所有HTTP请求 */
- (void)wqx_cancelAllRequest {
    @synchronized (self) {
        for (id obj in self.wqx_sessionTaskArray) {
            [((NSURLSessionTask *)obj) cancel];
        }
        [self.wqx_sessionTaskArray removeAllObjects];
    }
}

/** 设置HTTPHeader */
- (void)wqx_setValue:(NSString *)value forHTTPHeaderField:(NSString *)field {
    [self.wqx_sessionManager.requestSerializer setValue:value forHTTPHeaderField:field];
}

/**
 配置自建证书的HTTPS请求, 参考链接: http://blog.csdn.net/syg90178aw/article/details/52839103

 @param cerPath 自建HTTPS证书的路径
 @param validatesDomainName 是否需要验证域名，默认为YES. 如果证书的域名与请求的域名不一致，需设置为NO;

 即服务器使用其他可信任机构颁发的证书，也可以建立连接，这个非常危险, 建议打开.validatesDomainName = NO, 主要用于这种情况:客户端请求的是子域名, 而证书上的是另外一个域名。
 因为SSL证书上的域名是独立的,假如证书上注册的域名是www.example.com, 那么mail.example.com是无法验证通过的.
 */
- (void)wqx_setSecurityPolicyWithCerPath:(NSString *)cerPath validatesDomainName:(BOOL)validatesDomainName {
    NSData *cerData = [NSData dataWithContentsOfFile:cerPath];
    // 使用证书验证模式
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    // 如果需要验证自建证书(无效证书)，需要设置为YES
    securityPolicy.allowInvalidCertificates = YES;
    // 是否需要验证域名，默认为YES;
    securityPolicy.validatesDomainName = validatesDomainName;
    securityPolicy.pinnedCertificates = [[NSSet alloc] initWithObjects:cerData, nil];
    [self.wqx_sessionManager setSecurityPolicy:securityPolicy];
}

@end
