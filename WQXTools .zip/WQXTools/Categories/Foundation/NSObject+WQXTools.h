//
//  NSObject+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (WQXTools)

/** 突破空间限制，随时随地弹出系统Alert */
- (void)wqx_showAlertWithTitle:(NSString *)title
                       message:(NSString *)message
                   cancelTitle:(NSString *)cancelTitle
                 cancelHandler:(void (^)(void))cancelHandler
                  confirmTitle:(NSString *)confirmTitle
                confirmHandler:(void (^)(void))confirmHandler;

/** 突破空间限制，随时随地弹出一个带有输入框的系统Alert */
- (void)wqx_showTextInputAlertWithTitle:(NSString *)title
                                message:(NSString *)message
          textFieldConfigurationHandler:(void (^)(UITextField *textField))textFieldConfigurationHandler
                            cancelTitle:(NSString *)cancelTitle
                          cancelHandler:(void (^)(void))cancelHandler
                           confirmTitle:(NSString *)confirmTitle
                         confirmHandler:(void (^)(NSString *text))confirmHandler;

/** 突破空间限制，随时随地弹出系统ActionSheet */
- (void)wqx_showActionSheetWithTitle:(NSString *)title
                             message:(NSString *)message
                         cancelTitle:(NSString *)cancelTitle
                       cancelHandler:(void (^)(void))cancelHandler
                    destructiveTitle:(NSString *)destructiveTitle
                  destructiveHandler:(void (^)(void))destructiveHandler
                         otherTitles:(NSArray<NSString *> *)otherTitles
                        otherHandler:(void (^)(NSInteger index))otherHandler;

@end

NS_ASSUME_NONNULL_END
