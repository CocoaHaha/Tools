//
//  NSDictionary+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "NSDictionary+WQXTools.h"

@implementation NSDictionary (WQXTools)

#ifdef DEBUG
/** 在控制台输出时可以将unicode转为中文 */
- (NSString *)descriptionWithLocale:(id)locale {
    NSMutableString *mutableString = [NSMutableString stringWithString:@"{\n"];
    [self enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        [mutableString appendFormat:@"\t%@ = %@;\n", key, obj];
    }];
    [mutableString appendString:@"}\n"];
    return mutableString;
}
#endif

@end
