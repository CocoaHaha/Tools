//
//  NSArray+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "NSArray+WQXTools.h"

@implementation NSArray (WQXTools)

#ifdef DEBUG
/** 在控制台输出时可以将unicode转为中文 */
- (NSString *)descriptionWithLocale:(id)locale {
    NSMutableString *mutableString = [NSMutableString stringWithString:@"(\n"];
    [self enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [mutableString appendFormat:@"\t%@,\n", obj];
    }];
    [mutableString appendString:@")"];
    return mutableString;
}
#endif

@end
