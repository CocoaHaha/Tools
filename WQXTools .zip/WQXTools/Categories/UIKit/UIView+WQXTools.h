//
//  UIView+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (WQXTools)

/** 设置view的四个圆角 */
- (void)wqx_setCorners:(UIRectCorner)corners cornerRadius:(CGFloat)cornerRadius;

@end

NS_ASSUME_NONNULL_END
