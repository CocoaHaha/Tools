//
//  UICollectionView+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "UICollectionView+WQXTools.h"

@implementation UICollectionView (WQXTools)

+ (instancetype)wqx_initWithCollectionViewFlowLayout {
    return [self wqx_initWithCollectionViewLayout:[[UICollectionViewFlowLayout alloc] init]];
}

+ (instancetype)wqx_initWithCollectionViewLayout:(UICollectionViewLayout *)layout {
    return [[self alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
}

@end
