//
//  UITableView+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITableView (WQXTools)

/** 快速创建一个UITableView，frame为CGRectZero，style为UITableViewStylePlain */
+ (instancetype)wqx_initWithPlainStyle;

/** 快速创建一个UITableView，frame为CGRectZero，style为UITableViewStyleGrouped */
+ (instancetype)wqx_initWithGroupedStyle;

/**
 获取复用队列里面的cell，如果获取不到则会创建一个cell
 内部会根据cellClass生成identifier，然后根据该identifier获取复用队列里面的cell
 如果获取不到，则会根据cellClass以及style创建一个cell
 */
- (id)wqx_dequeueReusableCellWithCellClass:(Class)cellClass style:(UITableViewCellStyle)style;

/**
 获取复用队列里面的cell，如果获取不到则会创建一个cell
 根据identifier获取复用队列里面的cell，如果获取不到则会根据cellClass以及style创建一个cell
 */
- (id)wqx_dequeueReusableCellWithCellClass:(Class)cellClass reuseIdentifier:(NSString *)reuseIdentifier style:(UITableViewCellStyle)style;

- (void)wqx_setHeight:(CGFloat)height forHeaderInSection:(NSInteger)section;
- (void)wqx_setHeight:(CGFloat)height forFooterInSection:(NSInteger)section;
- (void)wqx_setHeight:(CGFloat)height forCellAtIndexPath:(NSIndexPath *)indexPath;

- (CGFloat)wqx_getHeightForHeaderInSection:(NSInteger)section;
- (CGFloat)wqx_getHeightForFooterInSection:(NSInteger)section;
- (CGFloat)wqx_getHeightForCellAtIndexPath:(NSIndexPath *)indexPath;

@end

NS_ASSUME_NONNULL_END
