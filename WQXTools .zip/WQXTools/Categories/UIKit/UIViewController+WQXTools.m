//
//  UIViewController+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "UIViewController+WQXTools.h"

#import <objc/runtime.h>

const void *wqx_viewController_prefersNavigationBarHiddenKey;

@implementation UIViewController (WQXTools)

- (void)wqx_setDefaultNavigationBar {
    self.navigationController.navigationBar.translucent = YES;
    [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:nil];
}

- (void)wqx_setTransparentNavigationBar {
    self.navigationController.navigationBar.translucent = YES;
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}

- (void)wqx_showAlertWithTitle:(NSString *)title message:(NSString *)message cancelTitle:(NSString *)cancelTitle cancelHandler:(void (^)(void))cancelHandler confirmTitle:(NSString *)confirmTitle confirmHandler:(void (^)(void))confirmHandler{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    if (cancelTitle && [cancelTitle isKindOfClass:[NSString class]] && cancelTitle.length > 0) {
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            cancelHandler ? cancelHandler() : nil;
        }];
        [alert addAction:cancel];
    }
    if (confirmTitle && [confirmTitle isKindOfClass:[NSString class]] && confirmTitle.length > 0) {
        UIAlertAction *confirm = [UIAlertAction actionWithTitle:confirmTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            confirmHandler ? confirmHandler() : nil;
        }];
        [alert addAction:confirm];
    }
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)wqx_showTextInputAlertWithTitle:(NSString *)title message:(NSString *)message textFieldConfigurationHandler:(void (^)(UITextField *textField))textFieldConfigurationHandler cancelTitle:(NSString *)cancelTitle cancelHandler:(void (^)(void))cancelHandler confirmTitle:(NSString *)confirmTitle confirmHandler:(void (^)(NSString *text))confirmHandler{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:textFieldConfigurationHandler];
    if (cancelTitle && [cancelTitle isKindOfClass:[NSString class]] && cancelTitle.length > 0) {
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            cancelHandler ? cancelHandler() : nil;
        }];
        [alert addAction:cancel];
    }
    if (confirmTitle && [confirmTitle isKindOfClass:[NSString class]] && confirmTitle.length > 0) {
        UIAlertAction *confirm = [UIAlertAction actionWithTitle:confirmTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            confirmHandler ? confirmHandler(alert.textFields.firstObject.text) : nil;
        }];
        [alert addAction:confirm];
    }
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)wqx_showActionSheetWithTitle:(NSString *)title message:(NSString *)message cancelTitle:(NSString *)cancelTitle cancelHandler:(void (^)(void))cancelHandler destructiveTitle:(NSString *)destructiveTitle destructiveHandler:(void (^)(void))destructiveHandler otherTitles:(NSArray<NSString *> *)otherTitles otherHandler:(void (^)(NSInteger index))otherHandler{
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleActionSheet];
    if (cancelTitle && [cancelTitle isKindOfClass:[NSString class]] && cancelTitle.length > 0) {
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            cancelHandler ? cancelHandler() : nil;
        }];
        [actionSheet addAction:cancel];
    }
    if (destructiveTitle && [destructiveTitle isKindOfClass:[NSString class]] && destructiveTitle.length > 0) {
        UIAlertAction *destructive = [UIAlertAction actionWithTitle:destructiveTitle style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            destructiveHandler ? destructiveHandler() : nil;
        }];
        [actionSheet addAction:destructive];
    }
    if (otherTitles && [otherTitles isKindOfClass:[NSArray class]] && otherTitles.count > 0) {
        for (int i = 0; i < otherTitles.count; i ++) {
            UIAlertAction *action = [UIAlertAction actionWithTitle:otherTitles[i] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                otherHandler ? otherHandler(i) : nil;
            }];
            [actionSheet addAction:action];
        }
    }
    [self presentViewController:actionSheet animated:YES completion:nil];
}

@end
