//
//  UITableViewHeaderFooterView+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITableViewHeaderFooterView (WQXTools)

@property (nonatomic, strong) UITableView *wqx_tableView;
@property (nonatomic, assign) NSInteger wqx_section;
@property (nonatomic, assign) BOOL wqx_isHeaderView;

- (void)wqx_setHeight:(CGFloat)height;

@end

NS_ASSUME_NONNULL_END
