//
//  UIColor+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "UIColor+WQXTools.h"

@implementation UIColor (WQXTools)

+ (UIColor *)wqx_colorFromHexString:(NSString *)hexString {
    NSCharacterSet *set = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    hexString = [[hexString stringByTrimmingCharactersInSet:set] uppercaseString];
    if ([hexString hasPrefix:@"#"]) {
        hexString = [hexString substringFromIndex:1];
    }else if ([hexString hasPrefix:@"0X"]) {
        hexString = [hexString substringFromIndex:2];
    }
    // RGB、RGBA、RRGGBB、RRGGBBAA
    if (hexString.length != 3 && hexString.length != 4 && hexString.length != 6 && hexString.length != 8) {
        return nil;
    }
    CGFloat r, g, b, a;
    if (hexString.length < 5) {
        // RGB、RGBA
        r = strtoul([[hexString substringWithRange:NSMakeRange(0, 1)] UTF8String], 0, 16) / 255.0f;
        g = strtoul([[hexString substringWithRange:NSMakeRange(1, 1)] UTF8String], 0, 16) / 255.0f;
        b = strtoul([[hexString substringWithRange:NSMakeRange(2, 1)] UTF8String], 0, 16) / 255.0f;
        if (hexString.length == 4) {
            a = strtoul([[hexString substringWithRange:NSMakeRange(3, 1)] UTF8String], 0, 16) / 255.0f;
        }else {
            a = 1;
        }
    }else {
        // RRGGBB、RRGGBBAA
        r = strtoul([[hexString substringWithRange:NSMakeRange(0, 2)] UTF8String], 0, 16) / 255.0f;
        g = strtoul([[hexString substringWithRange:NSMakeRange(2, 2)] UTF8String], 0, 16) / 255.0f;
        b = strtoul([[hexString substringWithRange:NSMakeRange(4, 2)] UTF8String], 0, 16) / 255.0f;
        if (hexString.length == 8) {
            a = strtoul([[hexString substringWithRange:NSMakeRange(6, 2)] UTF8String], 0, 16) / 255.0f;
        }else {
            a = 1;
        }
    }
    return [UIColor colorWithRed:r green:g blue:b alpha:a];
}

@end
