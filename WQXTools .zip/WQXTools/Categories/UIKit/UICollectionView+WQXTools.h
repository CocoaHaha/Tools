//
//  UICollectionView+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UICollectionView (WQXTools)

/** 快速创建一个UICollectionView，frame为CGRectZero，layout为UICollectionViewFlowLayout */
+ (instancetype)wqx_initWithCollectionViewFlowLayout;

/** 快速创建一个UICollectionView，frame为CGRectZero */
+ (instancetype)wqx_initWithCollectionViewLayout:(UICollectionViewLayout *)layout;

@end

NS_ASSUME_NONNULL_END
