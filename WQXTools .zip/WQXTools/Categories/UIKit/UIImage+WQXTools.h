//
//  UIImage+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (WQXTools)

/** 生成纯色图片 */
+ (UIImage *)wqx_imageWithColor:(UIColor *)color size:(CGSize)size;

/** 生成渐变图片 */
+ (UIImage *)wqx_imageWithColors:(NSArray<UIColor *> *)colors
                       locations:(NSArray<NSNumber *> *)locations
                      startPoint:(CGPoint)startPoint
                        endPoint:(CGPoint)endPoint
                            size:(CGSize)size;

@end

NS_ASSUME_NONNULL_END
