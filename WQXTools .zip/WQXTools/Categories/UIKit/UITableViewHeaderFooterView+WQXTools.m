//
//  UITableViewHeaderFooterView+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "UITableViewHeaderFooterView+WQXTools.h"

#import <objc/runtime.h>
#import "UITableView+WQXTools.h"

const void *wqx_tableViewHeaderFooterView_tableViewKey;
const void *wqx_tableViewHeaderFooterView_sectionKey;
const void *wqx_tableViewHeaderFooterView_isHeaderViewKey;

@implementation UITableViewHeaderFooterView (WQXTools)

- (void)setWqx_tableView:(UITableView *)wqx_tableView {
    objc_setAssociatedObject(self, &wqx_tableViewHeaderFooterView_tableViewKey, wqx_tableView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)setWqx_section:(NSInteger)wqx_section {
    objc_setAssociatedObject(self, &wqx_tableViewHeaderFooterView_sectionKey, [NSNumber numberWithInteger:wqx_section], OBJC_ASSOCIATION_ASSIGN);
}

- (void)setWqx_isHeaderView:(BOOL)wqx_isHeaderView {
    objc_setAssociatedObject(self, &wqx_tableViewHeaderFooterView_isHeaderViewKey, [NSNumber numberWithBool:wqx_isHeaderView], OBJC_ASSOCIATION_ASSIGN);
}

- (UITableView *)wqx_tableView {
    return objc_getAssociatedObject(self, &wqx_tableViewHeaderFooterView_tableViewKey);
}

- (NSInteger)wqx_section {
    NSNumber *object = objc_getAssociatedObject(self, &wqx_tableViewHeaderFooterView_sectionKey);
    return object.integerValue;
}

- (BOOL)wqx_isHeaderView {
    NSNumber *object = objc_getAssociatedObject(self, &wqx_tableViewHeaderFooterView_isHeaderViewKey);
    return object.boolValue;
}

- (void)wqx_setHeight:(CGFloat)height {
    if (self.wqx_isHeaderView) {
        [self.wqx_tableView wqx_setHeight:height forHeaderInSection:self.wqx_section];
    }else{
        [self.wqx_tableView wqx_setHeight:height forFooterInSection:self.wqx_section];
    }
}
@end
