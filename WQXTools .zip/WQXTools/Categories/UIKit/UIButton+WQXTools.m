//
//  UIButton+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "UIButton+WQXTools.h"

@implementation UIButton (WQXTools)

- (void)wqx_contentInsetWithMode:(NSInteger)mode margin:(CGFloat)margin {
    if (mode == 1) {
        self.titleEdgeInsets = UIEdgeInsetsMake(0, -(margin / 2 + self.imageView.frame.size.width) * 2, 0, 0);
        self.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -(margin / 2 + self.titleLabel.intrinsicContentSize.width) * 2);
    }else if (mode == 2) {
        self.titleEdgeInsets = UIEdgeInsetsMake(0, -self.imageView.frame.size.width, -(self.imageView.frame.size.height + margin / 2), 0);
        self.imageEdgeInsets = UIEdgeInsetsMake(-(self.titleLabel.intrinsicContentSize.height + margin / 2), 0, 0, -self.titleLabel.intrinsicContentSize.width);
    }else if (mode == 3) {
        self.titleEdgeInsets = UIEdgeInsetsMake(-(self.imageView.frame.size.height + margin / 2), -self.imageView.frame.size.width, 0, 0);
        self.imageEdgeInsets = UIEdgeInsetsMake(0, 0, -(self.titleLabel.intrinsicContentSize.height + margin / 2), -self.titleLabel.intrinsicContentSize.width);
    }else {
        self.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, -margin / 2);
        self.imageEdgeInsets = UIEdgeInsetsMake(0, -margin / 2, 0, 0);
    }
}

@end
