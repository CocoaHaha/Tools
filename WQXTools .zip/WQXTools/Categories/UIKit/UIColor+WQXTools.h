//
//  UIColor+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (WQXTools)

/** 16进制颜色转10进制颜色 */
+ (UIColor *)wqx_colorFromHexString:(NSString *)hexString;

@end

NS_ASSUME_NONNULL_END
