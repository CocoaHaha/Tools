//
//  UIViewController+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (WQXTools)

/** 设置为默认导航栏 */
- (void)wqx_setDefaultNavigationBar;

/** 设置为透明导航栏 */
- (void)wqx_setTransparentNavigationBar;

/** 弹出系统Alert */
- (void)wqx_showAlertWithTitle:(NSString *)title
                       message:(NSString *)message
                   cancelTitle:(NSString *)cancelTitle
                 cancelHandler:(void (^)(void))cancelHandler
                  confirmTitle:(NSString *)confirmTitle
                confirmHandler:(void (^)(void))confirmHandler;

/** 弹出一个带有输入框的系统Alert */
- (void)wqx_showTextInputAlertWithTitle:(NSString *)title
                                message:(NSString *)message
          textFieldConfigurationHandler:(void (^)(UITextField *textField))textFieldConfigurationHandler
                            cancelTitle:(NSString *)cancelTitle
                          cancelHandler:(void (^)(void))cancelHandler
                           confirmTitle:(NSString *)confirmTitle
                         confirmHandler:(void (^)(NSString *text))confirmHandler;

/** 弹出系统ActionSheet */
- (void)wqx_showActionSheetWithTitle:(NSString *)title
                             message:(NSString *)message
                         cancelTitle:(NSString *)cancelTitle
                       cancelHandler:(void (^)(void))cancelHandler
                    destructiveTitle:(NSString *)destructiveTitle
                  destructiveHandler:(void (^)(void))destructiveHandler
                         otherTitles:(NSArray<NSString *> *)otherTitles
                        otherHandler:(void (^)(NSInteger index))otherHandler;

@end

NS_ASSUME_NONNULL_END
