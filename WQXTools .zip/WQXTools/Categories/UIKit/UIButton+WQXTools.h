//
//  UIButton+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (WQXTools)

/**
 设置图片和文字的布局，margin是图片与文字的间距
 0：图片在左，文字在右，默认就是这个
 1：图片在右，文字在左
 2：图片在上，文字在下
 3：图片在下，文字在上
 */
- (void)wqx_contentInsetWithMode:(NSInteger)mode margin:(CGFloat)margin;

@end

NS_ASSUME_NONNULL_END
