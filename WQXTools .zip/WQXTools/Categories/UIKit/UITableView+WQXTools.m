//
//  UITableView+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "UITableView+WQXTools.h"

#import <objc/runtime.h>

@interface UITableView ()

@property (nonatomic, strong) NSMutableDictionary *wqx_headerHeightCacheDictionary;
@property (nonatomic, strong) NSMutableDictionary *wqx_footerHeightCacheDictionary;
@property (nonatomic, strong) NSMutableDictionary *wqx_cellHeightCacheDictionary;

@end

const void *wqx_tableView_headerHeightCacheDictionaryKey;
const void *wqx_tableView_footerHeightCacheDictionaryKey;
const void *wqx_tableView_cellHeightCacheDictionaryKey;

@implementation UITableView (WQXTools)

#pragma mark - property
- (void)setWqx_headerHeightCacheDictionary:(NSMutableDictionary *)wqx_headerHeightCacheDictionary {
    objc_setAssociatedObject(self, &wqx_tableView_headerHeightCacheDictionaryKey, wqx_headerHeightCacheDictionary, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)setWqx_footerHeightCacheDictionary:(NSMutableDictionary *)wqx_footerHeightCacheDictionary {
    objc_setAssociatedObject(self, &wqx_tableView_footerHeightCacheDictionaryKey, wqx_footerHeightCacheDictionary, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)setWqx_cellHeightCacheDictionary:(NSMutableDictionary *)wqx_cellHeightCacheDictionary {
    objc_setAssociatedObject(self, &wqx_tableView_cellHeightCacheDictionaryKey, wqx_cellHeightCacheDictionary, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (NSMutableDictionary *)wqx_headerHeightCacheDictionary {
    return objc_getAssociatedObject(self, &wqx_tableView_headerHeightCacheDictionaryKey);
}

- (NSMutableDictionary *)wqx_footerHeightCacheDictionary {
    return objc_getAssociatedObject(self, &wqx_tableView_footerHeightCacheDictionaryKey);
}

- (NSMutableDictionary *)wqx_cellHeightCacheDictionary {
    return objc_getAssociatedObject(self, &wqx_tableView_cellHeightCacheDictionaryKey);
}

#pragma mark - method
+ (instancetype)wqx_initWithPlainStyle {
    return [[self alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
}

+ (instancetype)wqx_initWithGroupedStyle {
    return [[self alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
}

- (id)wqx_dequeueReusableCellWithCellClass:(Class)cellClass style:(UITableViewCellStyle)style {
//    NSAssert(cellClass, @"cellClass 不能为nil，cellClass can not be nil");
//    /*
//     这行代码会有性能问题（有可能会在一瞬间创建大量的cell），目前没有想到优雅的解决方案，暂时不判断了，自己去检查吧😊
//     NSAssert([[cellClass new] isKindOfClass:[UITableViewCell class]], @"cellClass只能是UITableViewCell类或其子类");
//     */
//    NSString *identifier = NSStringFromClass(cellClass);
//    UITableViewCell *cell = [self dequeueReusableCellWithIdentifier:identifier];
//    if (!cell) {
//        cell = [[cellClass alloc] initWithStyle:style reuseIdentifier:identifier];
//    }
//    return cell;
    return [self wqx_dequeueReusableCellWithCellClass:cellClass reuseIdentifier:NSStringFromClass(cellClass) style:style];
}

- (id)wqx_dequeueReusableCellWithCellClass:(Class)cellClass reuseIdentifier:(NSString *)reuseIdentifier style:(UITableViewCellStyle)style {
    NSAssert(cellClass, @"cellClass不能为nil，cellClass can not be nil");
    NSAssert([cellClass isSubclassOfClass:[UITableViewCell class]], @"cellClass只能是UITableViewCell类或其子类");
    NSAssert(reuseIdentifier, @"reuseIdentifier不能为nil，reuseIdentifier can not be nil");
    NSAssert([reuseIdentifier isKindOfClass:[NSString class]], @"reuseIdentifier必须为NSString");
    /*
     这行代码会有性能问题（有可能会在一瞬间创建大量的cell），目前没有想到优雅的解决方案，暂时不判断了，自己去检查吧😊
     NSAssert([[cellClass new] isKindOfClass:[UITableViewCell class]], @"cellClass只能是UITableViewCell类或其子类");
     */
    UITableViewCell *cell = [self dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) {
        cell = [[cellClass alloc] initWithStyle:style reuseIdentifier:reuseIdentifier];
    }
    return cell;
}

- (void)wqx_setHeight:(CGFloat)height forHeaderInSection:(NSInteger)section {
    if (self.wqx_headerHeightCacheDictionary == nil) {
        self.wqx_headerHeightCacheDictionary = [[NSMutableDictionary alloc] init];
    }
    NSNumber *object = [NSNumber numberWithFloat:height];
    NSString *key = [NSString stringWithFormat:@"%ld", section];
    [self.wqx_headerHeightCacheDictionary setObject:object forKey:key];
}

- (void)wqx_setHeight:(CGFloat)height forFooterInSection:(NSInteger)section {
    if (self.wqx_footerHeightCacheDictionary == nil) {
        self.wqx_footerHeightCacheDictionary = [[NSMutableDictionary alloc] init];
    }
    NSNumber *object = [NSNumber numberWithFloat:height];
    NSString *key = [NSString stringWithFormat:@"%ld", section];
    [self.wqx_footerHeightCacheDictionary setObject:object forKey:key];
}

- (void)wqx_setHeight:(CGFloat)height forCellAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath == nil) return;
    if (self.wqx_cellHeightCacheDictionary == nil) {
        self.wqx_cellHeightCacheDictionary = [[NSMutableDictionary alloc] init];
    }
    NSNumber *object = [NSNumber numberWithFloat:height];
    NSString *key = [NSString stringWithFormat:@"%ld.%ld", indexPath.section, indexPath.row];
    [self.wqx_cellHeightCacheDictionary setObject:object forKey:key];
}

- (CGFloat)wqx_getHeightForHeaderInSection:(NSInteger)section {
    NSString *key = [NSString stringWithFormat:@"%ld", section];
    NSNumber *object = [self.wqx_headerHeightCacheDictionary objectForKey:key];
    if (object == nil) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(tableView:viewForHeaderInSection:)]) {
            [self.delegate tableView:self viewForHeaderInSection:section];
            object = [self.wqx_headerHeightCacheDictionary objectForKey:key];
        }else if (self.delegate && [self.dataSource respondsToSelector:@selector(tableView:titleForHeaderInSection:)]) {
            [self.dataSource tableView:self titleForHeaderInSection:section];
            object = [self.wqx_headerHeightCacheDictionary objectForKey:key];
        }
    }
    return object.floatValue;
}

- (CGFloat)wqx_getHeightForFooterInSection:(NSInteger)section {
    NSString *key = [NSString stringWithFormat:@"%ld", section];
    NSNumber *object = [self.wqx_footerHeightCacheDictionary objectForKey:key];
    if (object == nil) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(tableView:viewForFooterInSection:)]) {
            [self.delegate tableView:self viewForFooterInSection:section];
            object = [self.wqx_footerHeightCacheDictionary objectForKey:key];
        }else if (self.dataSource && [self.dataSource respondsToSelector:@selector(tableView:titleForFooterInSection:)]) {
            [self.dataSource tableView:self titleForFooterInSection:section];
            object = [self.wqx_footerHeightCacheDictionary objectForKey:key];
        }
    }
    return object.floatValue;
}

- (CGFloat)wqx_getHeightForCellAtIndexPath:(NSIndexPath *)indexPath {
    NSString *key = [NSString stringWithFormat:@"%ld.%ld", indexPath.section, indexPath.row];
    NSNumber *object = [self.wqx_cellHeightCacheDictionary objectForKey:key];
    return object.floatValue;
}

@end
