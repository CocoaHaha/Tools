//
//  UITableViewCell+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITableViewCell (WQXTools)

@property (nonatomic, strong) UITableView *wqx_tableView;
@property (nonatomic, strong) NSIndexPath *wqx_indexPath;

- (void)wqx_setHeight:(CGFloat)height;

@end

NS_ASSUME_NONNULL_END
