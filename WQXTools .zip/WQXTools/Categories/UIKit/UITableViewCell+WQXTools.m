//
//  UITableViewCell+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "UITableViewCell+WQXTools.h"

#import <objc/runtime.h>
#import "UITableView+WQXTools.h"

const void *wqx_tableViewCell_tableViewKey;
const void *wqx_tableViewCell_indexPathKey;

@implementation UITableViewCell (WQXTools)

- (void)setWqx_tableView:(UITableView *)wqx_tableView {
    objc_setAssociatedObject(self, &wqx_tableViewCell_tableViewKey, wqx_tableView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)setWqx_indexPath:(NSIndexPath *)wqx_indexPath {
    objc_setAssociatedObject(self, &wqx_tableViewCell_indexPathKey, wqx_indexPath, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UITableView *)wqx_tableView {
    return objc_getAssociatedObject(self, &wqx_tableViewCell_tableViewKey);
}

- (NSIndexPath *)wqx_indexPath {
    return objc_getAssociatedObject(self, &wqx_tableViewCell_indexPathKey);
}

- (void)wqx_setHeight:(CGFloat)height {
    [self.wqx_tableView wqx_setHeight:height forCellAtIndexPath:self.wqx_indexPath];
}

@end
