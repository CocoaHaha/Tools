//
//  UIImage+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/11/23.
//

#import "UIImage+WQXTools.h"

@implementation UIImage (WQXTools)

+ (UIImage *)wqx_imageWithColor:(UIColor *)color size:(CGSize)size {
    if (!color || size.width <= 0 || size.height <= 0) return nil;
    CGRect rect = CGRectMake(0.0f, 0.0f, size.width, size.height);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

+ (UIImage *)wqx_imageWithColors:(NSArray<UIColor *> *)colors
                       locations:(NSArray<NSNumber *> *)locations
                      startPoint:(CGPoint)startPoint
                        endPoint:(CGPoint)endPoint
                            size:(CGSize)size {
    if (!colors || colors.count <= 0 || size.width <= 0 || size.height <= 0) return nil;
    UIGraphicsBeginImageContext(size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    if (!context) return nil;
    NSMutableArray *cgColors = [[NSMutableArray alloc] init];
    for (UIColor *color in colors) {
        [cgColors addObject:(__bridge id)color.CGColor];
    }
    CAGradientLayer *layer = [[CAGradientLayer alloc] init];
    layer.frame = CGRectMake(0, 0, size.width, size.height);
    layer.colors = cgColors;
    layer.locations = locations;
    layer.startPoint = startPoint;
    layer.endPoint = endPoint;
    [layer renderInContext:context];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end
