//
//  AppDelegate+WQXTools.h
//  WQXTools
//
//  Created by 温群香 on 2020/12/16.
//

#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (WQXTools)

/** 允许的方向，设置该值之后会自动切换到相应的方向 */
@property (nonatomic, assign) UIDeviceOrientation allowOrientation;

@end

NS_ASSUME_NONNULL_END
