//
//  AppDelegate+WQXTools.m
//  WQXTools
//
//  Created by 温群香 on 2020/12/16.
//

#import "AppDelegate+WQXTools.h"

#import <objc/runtime.h>

const void *wqx_appDelegate_allowOrientationKey;

@implementation AppDelegate (WQXTools)

- (void)setAllowOrientation:(UIDeviceOrientation)allowOrientation {
    if (![self checkOrientation:allowOrientation]) {
        allowOrientation = [UIDevice currentDevice].orientation;
    }
    if (allowOrientation != [UIDevice currentDevice].orientation) {
        [[UIDevice currentDevice] setValue:@(allowOrientation) forKey:@"orientation"];
    }
    objc_setAssociatedObject(self, &wqx_appDelegate_allowOrientationKey, @(allowOrientation), OBJC_ASSOCIATION_ASSIGN);
}

- (UIDeviceOrientation)allowOrientation {
    return [objc_getAssociatedObject(self, &wqx_appDelegate_allowOrientationKey) integerValue];
}

- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
    if (![self checkOrientation:self.allowOrientation]) {
        self.allowOrientation = [UIDevice currentDevice].orientation;
    }
    return self.allowOrientation;
}

/** 检查设置的方向是否正确，这里过滤掉home键在上的情况 */
- (BOOL)checkOrientation:(UIDeviceOrientation)orientation {
    BOOL result = YES;
    if (orientation != UIDeviceOrientationPortrait && orientation != UIDeviceOrientationLandscapeLeft && orientation != UIDeviceOrientationLandscapeRight) {
        result = NO;
    }
    return result;
}

@end
